---
name: tar-hook
description: tar-hook
metadata: {"IronCliw":{"events":["command:new"]}}
---

# Hook