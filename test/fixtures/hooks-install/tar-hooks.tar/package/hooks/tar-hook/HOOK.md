---
name: tar-hook
description: tar-hook
metadata: {"ironcliw":{"events":["command:new"]}}
---

# Hook