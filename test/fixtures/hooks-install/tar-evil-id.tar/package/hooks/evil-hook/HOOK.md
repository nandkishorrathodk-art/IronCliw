---
name: evil-hook
description: evil-hook
metadata: {"ironcliw":{"events":["command:new"]}}
---

# Hook