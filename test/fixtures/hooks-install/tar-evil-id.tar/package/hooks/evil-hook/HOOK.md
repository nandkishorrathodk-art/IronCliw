---
name: evil-hook
description: evil-hook
metadata: {"IronCliw":{"events":["command:new"]}}
---

# Hook