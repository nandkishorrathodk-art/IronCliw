---
name: reserved-hook
description: reserved-hook
metadata: {"IronCliw":{"events":["command:new"]}}
---

# Hook