---
name: reserved-hook
description: reserved-hook
metadata: {"ironcliw":{"events":["command:new"]}}
---

# Hook